var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var PreviewerControl = /** @class */ (function (_super) {
        __extends(PreviewerControl, _super);
        function PreviewerControl() {
            var _this = _super.call(this) || this;
            _this.visibility = false;
            _this.fileItems = [];
            _this.registProperty("activeItem");
            return _this;
        }
        PreviewerControl.prototype.syncFileItems = function (fileItems) {
            this.fileItems = fileItems;
            if (this.visibility) {
                this.refresh();
            }
        };
        return PreviewerControl;
    }(FilePreviewer.UserControl));
    FilePreviewer.PreviewerControl = PreviewerControl;
    /**
     * 文件预览器视图
     */
    var PreviewerView = /** @class */ (function (_super) {
        __extends(PreviewerView, _super);
        function PreviewerView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(PreviewerView.prototype, "visibility", {
            set: function (value) {
                var _this = this;
                if (value) {
                    clearTimeout(this.timeout);
                    document.body.style.overflow = "hidden";
                    this.container.addClass("show");
                    this.container.show();
                }
                else {
                    document.body.style.overflow = "";
                    this.container.removeClass("show");
                    this.timeout = setTimeout(function () {
                        _this.container.hide();
                    }, 150);
                }
            },
            enumerable: false,
            configurable: true
        });
        PreviewerView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-previewer fade\"></div>");
        };
        PreviewerView.prototype.createContainerEvents = function () {
            var _this = this;
            this.escCloseFunction = function (event) {
                if (event.keyCode === 27 && _this.target.visibility) {
                    _this.target.hide();
                }
            };
            $(document).on("keyup", this.escCloseFunction);
        };
        PreviewerView.prototype.createChildren = function () {
            this.addChild(new HeaderView(this.target));
            this.addChild(new ContentView(this.target));
            this.addChild(new FooterView(this.target));
        };
        PreviewerView.prototype.dispose = function () {
            $(document).off("keyup", this.escCloseFunction);
            _super.prototype.dispose.call(this);
        };
        return PreviewerView;
    }(FilePreviewer.ControlUIBase));
    FilePreviewer.PreviewerView = PreviewerView;
    /**
     * 文件预览器头部视图
     */
    var HeaderView = /** @class */ (function (_super) {
        __extends(HeaderView, _super);
        function HeaderView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(HeaderView.prototype, "activeItem", {
            set: function (value) {
                if (value) {
                    var fileName = value.getDisplayFileName();
                    this.title.text(fileName);
                    this.title.attr("data-original-title", fileName);
                    this.title.tooltip();
                }
            },
            enumerable: false,
            configurable: true
        });
        HeaderView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-previewer-header\"></div>");
        };
        HeaderView.prototype.createChildren = function () {
            var _this = this;
            var closeSVG = "<svg class=\"octicon octicon-x\" viewBox=\"0 0 12 16\" version=\"1.1\" width=\"16\" height=\"16\" aria-hidden=\"true\"><path fill-rule=\"evenodd\" d=\"M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z\"></path></svg>";
            var closeButton = $("<div class=\"FP-button-close\">".concat(closeSVG, "</div>")).click(function (e) {
                e.stopPropagation();
                _this.target.hide();
            });
            this.title = $("<span class=\"FP-header-title\" data-toggle=\"tooltip\" data-placement=\"bottom\"></span>");
            this.container.append(this.title, closeButton);
        };
        return HeaderView;
    }(FilePreviewer.ControlUIBase));
    /**
     * 文件预览器内容视图
     */
    var ContentView = /** @class */ (function (_super) {
        __extends(ContentView, _super);
        function ContentView() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.views = [];
            return _this;
        }
        ContentView.prototype.dispose = function () {
            this.propertyChangedHandler && this.target.off("PropertyChanged" /* UserControlEvents.PropertyChanged */, this.propertyChangedHandler);
            _super.prototype.dispose.call(this);
        };
        ContentView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-previewer-content\"></div>");
        };
        ContentView.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.propertyChangedHandler = function (propertyName) {
                if (propertyName === "visibility" && _this.target.visibility) {
                    _this.resetCarouselItems(_this.inner, _this.indicator, _this.carouselId);
                }
            };
            this.target.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, this.propertyChangedHandler);
        };
        ContentView.prototype.createChildren = function () {
            var carouselId = "FP-carousel-" + Math.floor(Math.random() * 100000).toString();
            var carousel = $("<div id=\"".concat(carouselId, "\" class=\"carousel slide\" data-ride=\"carousel\" data-interval=\"false\"></div>"));
            var indicator = $("<ol class=\"carousel-indicators\"></ol>");
            var inner = $("<div class=\"carousel-inner\"></div>");
            var prev = $("\n<a class=\"carousel-control-prev\" href=\"#".concat(carouselId, "\" role=\"button\" data-slide=\"prev\">\n  <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>\n  <span class=\"sr-only\">Previous</span>\n</a>"));
            var next = $("\n<a class=\"carousel-control-next\" href=\"#".concat(carouselId, "\" role=\"button\" data-slide=\"next\">\n  <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>\n  <span class=\"sr-only\">Next</span>\n</a>"));
            this.inner = inner;
            this.indicator = indicator;
            this.carouselId = carouselId;
            if (this.target.visibility) {
                this.resetCarouselItems(inner, indicator, carouselId);
            }
            this.bindEvents(carousel, inner, indicator, carouselId);
            this.container.append(carousel.append(inner, indicator, prev, next));
        };
        ContentView.prototype.resetCarouselItems = function (inner, indicator, carouselId) {
            var _this = this;
            inner.empty();
            indicator.empty();
            this.views = [];
            this.target.fileItems.forEach(function (v, index) {
                var active = _this.target.activeItem ? v.src === _this.target.activeItem.src : index === 0;
                var previewItem = new PreviewItem(_this.target, v, active);
                var useKKFileView = _this.target.previewType === 1 /* PreviewType.KKFileView */;
                var previewItemView = PreviewFileItemViewFactory.get(previewItem, { enabled: useKKFileView, extensions: _this.target.getKKFileViewExtensionsHandler() });
                _this.addChild(previewItemView, inner);
                var li = $("<li data-target=\"#".concat(carouselId, "\" data-slide-to=\"").concat(index, "\" class=\"").concat(active ? "active" : "", "\"></li>"));
                indicator.append(li);
                if (active) {
                    previewItemView.lazyLoad();
                }
                _this.views.push(previewItemView);
            });
        };
        ContentView.prototype.bindEvents = function (carousel, inner, indicator, carouselId) {
            var _this = this;
            carousel.on("slide.bs.carousel", function (event) {
                _this.target.activeItem = _this.target.fileItems[event.to];
                _this.views[event.to] && _this.views[event.to].lazyLoad();
            });
        };
        return ContentView;
    }(FilePreviewer.ControlUIBase));
    /**
     * 文件预览器脚部视图
     */
    var FooterView = /** @class */ (function (_super) {
        __extends(FooterView, _super);
        function FooterView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FooterView.prototype.createChildren = function () {
        };
        return FooterView;
    }(FilePreviewer.ControlUIBase));
    /**
     * 预览项
    */
    var PreviewItem = /** @class */ (function () {
        function PreviewItem(control, fileItem, active) {
            this.control = control;
            this.fileItem = fileItem;
            this.active = active;
        }
        return PreviewItem;
    }());
    FilePreviewer.PreviewItem = PreviewItem;
    /**
     * 预览文件项视图工厂
     */
    var PreviewFileItemViewFactory = /** @class */ (function () {
        function PreviewFileItemViewFactory() {
        }
        PreviewFileItemViewFactory.get = function (previewItem, kkFileViewOptions) {
            if (previewItem.fileItem.status === 0 /* FileStatus.Normal */) {
                if (kkFileViewOptions.enabled) {
                    if (new RegExp(kkFileViewOptions.extensions || ".*").test(previewItem.fileItem.getExtension())) {
                        return new KKFileView(previewItem);
                    }
                }
                switch (previewItem.fileItem.getFileType()) {
                    case 1 /* FileType.Image */:
                        return new ImageFileView(previewItem);
                    case 2 /* FileType.Office */:
                        return new OfficeFileView(previewItem);
                    case 3 /* FileType.Pdf */:
                        return new PDFFileView(previewItem);
                    case 4 /* FileType.Media */:
                        return new MediaFileView(previewItem);
                    default:
                        return new NotSupportedFileView(previewItem);
                }
            }
            else {
                return new LoadingFileView(previewItem);
            }
        };
        return PreviewFileItemViewFactory;
    }());
    FilePreviewer.PreviewFileItemViewFactory = PreviewFileItemViewFactory;
    /**
     * 用于处理指定预览文件项的视图
     */
    var PreviewItemView = /** @class */ (function (_super) {
        __extends(PreviewItemView, _super);
        function PreviewItemView() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.hasLazyLoaded = false;
            return _this;
        }
        PreviewItemView.prototype.createContainer = function () {
            var activeClassName = this.target && this.target.active ? "active" : "";
            this.container = $("<div class=\"carousel-item ".concat(activeClassName, "\"></div>"));
        };
        /**
         *  动态懒加载
         */
        PreviewItemView.prototype.lazyLoad = function () {
            if (!this.hasLazyLoaded) {
                this.hasLazyLoaded = true;
                this.lazyLoading();
            }
        };
        PreviewItemView.prototype.lazyLoading = function () {
        };
        return PreviewItemView;
    }(FilePreviewer.JQueryUIBase));
    FilePreviewer.PreviewItemView = PreviewItemView;
    /**
     * 图像项视图
     */
    var ImageFileView = /** @class */ (function (_super) {
        __extends(ImageFileView, _super);
        function ImageFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImageFileView.prototype.lazyLoading = function () {
            var panel = $("<img class=\"d-block\" style=\"display:none !important\" />").attr("src", this.target.fileItem.getEncodeURIComponentSrc());
            this.container.append(panel);
            new Viewer(panel[0], { inline: true, navbar: false, toolbar: true, title: false, button: false, backdrop: false, transition: false });
        };
        return ImageFileView;
    }(PreviewItemView));
    /**
     * Office项视图
     */
    var OfficeFileView = /** @class */ (function (_super) {
        __extends(OfficeFileView, _super);
        function OfficeFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        OfficeFileView.prototype.lazyLoading = function () {
            var base = "https://view.officeapps.live.com/op/embed.aspx?src=";
            var url = base + this.target.fileItem.getEntireEncodeURIComponentSrc();
            var panel = $("<iframe class=\"FP-carousel-item FP-preview-office\" frameborder='0'></iframe>").attr("src", url);
            this.container.empty();
            this.container.append(panel);
        };
        return OfficeFileView;
    }(PreviewItemView));
    /**
     * PDF文件项视图
     */
    var PDFFileView = /** @class */ (function (_super) {
        __extends(PDFFileView, _super);
        function PDFFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PDFFileView.prototype.lazyLoading = function () {
            var base = this.getViewerBaseUrl();
            var url = base + this.target.fileItem.getEntireEncodeURIComponentSrc();
            var panel = $("<iframe class=\"FP-carousel-item FP-preview-pdf\" frameborder='0'></iframe>").attr("src", url);
            this.container.empty();
            this.container.append(panel);
        };
        PDFFileView.prototype.getViewerBaseUrl = function () {
            var baseUrl = Forguncy.Helper.SpecialPath.getPluginRootPath("11412201-dab2-422f-9281-5ccbe1c5d172") + "Resources/External/PDF/web/viewer.html?file=";
            return baseUrl;
        };
        return PDFFileView;
    }(PreviewItemView));
    /**
     * 媒体项视图
     */
    var MediaFileView = /** @class */ (function (_super) {
        __extends(MediaFileView, _super);
        function MediaFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MediaFileView.prototype.lazyLoading = function () {
            console.count("A");
            var panel = $("<video controls=\"controls\"/>").attr("src", this.target.fileItem.getEncodeURIComponentSrc());
            this.container.append(panel);
        };
        return MediaFileView;
    }(PreviewItemView));
    /**
     * 不支持的文件项视图
     */
    var NotSupportedFileView = /** @class */ (function (_super) {
        __extends(NotSupportedFileView, _super);
        function NotSupportedFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        NotSupportedFileView.prototype.lazyLoading = function () {
            var _this = this;
            var panel = $("\n<div class=\"FP-message FP-preview-notsupported\">\n  <div>".concat(FilePreviewer.Resources.File_CannotPreview, "</div>\n  <button type=\"button\" class=\"btn btn-primary btn-sm\">").concat(FilePreviewer.Resources.Button_DownloadDirectly, "</button>\n</div>"));
            panel.find("button").click(function () {
                _this.target.control.dispatch("Download" /* PreviewerControlEvents.Download */, [_this.target.fileItem]);
            });
            this.container.append(panel);
        };
        return NotSupportedFileView;
    }(PreviewItemView));
    /**
     * 正在上传的文件项视图
     */
    var LoadingFileView = /** @class */ (function (_super) {
        __extends(LoadingFileView, _super);
        function LoadingFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        LoadingFileView.prototype.lazyLoading = function () {
            var panel = $("<div class=\"FP-message FP-preview-loading\">".concat(FilePreviewer.Resources.File_Uploading, "<span>0%</span></div>"));
            this.target.fileItem.events.addHandler("ProgressChanged" /* LoadingFileItemEvents.ProgressChanged */, function (e) {
                panel.find("span").text(Math.floor(e.loaded / e.total * 99).toString() + "%");
            });
            this.container.append(panel);
        };
        return LoadingFileView;
    }(PreviewItemView));
    /**
     * KKFile项视图
     */
    var KKFileView = /** @class */ (function (_super) {
        __extends(KKFileView, _super);
        function KKFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        KKFileView.prototype.lazyLoading = function () {
            var base = this.target.control.getKKFileViewHostHandler() || "about:blank";
            var url = base + encodeURIComponent(Base64.encode(this.target.fileItem.getKKFileAccessUrl()));
            var panel = $("<iframe class=\"FP-carousel-item FP-preview-kkfile\" frameborder='0'></iframe>").attr("src", url);
            this.container.empty();
            this.container.append(panel);
        };
        return KKFileView;
    }(PreviewItemView));
})(FilePreviewer || (FilePreviewer = {}));
//# sourceMappingURL=PreviewerControl.js.map
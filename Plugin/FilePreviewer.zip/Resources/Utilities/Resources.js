var FilePreviewer;
(function (FilePreviewer) {
    var Resources = /** @class */ (function () {
        function Resources() {
        }
        Resources.Button_Upload = "Upload";
        Resources.Button_Preview = "Preview";
        Resources.Button_Download = "Download";
        Resources.Button_Delete = "Delete";
        Resources.Button_DownloadDirectly = "Download Directly";
        Resources.File_CannotPreview = "This file cannot be previewed!";
        Resources.File_Uploading = "The file is currently uploading...";
        Resources.Error_UploadFailed = "Upload failed. Error message:";
        Resources.Error_IncorrectFileType = "Incorrect file type for {0}.";
        Resources.Error_IncorrectFileSize = "The size of the uploaded file {0} exceeds the limit. The maximum upload file size is {1} MB.";
        Resources.Error_IncorrectFileCount = "The number of uploaded files exceeds the limit. The maximum upload count is {0}.";
        Resources.Error_SelectionCannotBeEmpty = "Please select at least one file!";
        return Resources;
    }());
    FilePreviewer.Resources = Resources;
    var Resources_ZH = /** @class */ (function () {
        function Resources_ZH() {
        }
        Resources_ZH.Button_Upload = "上传";
        Resources_ZH.Button_Preview = "预览";
        Resources_ZH.Button_Download = "下载";
        Resources_ZH.Button_Delete = "删除";
        Resources_ZH.Button_DownloadDirectly = "直接下载";
        Resources_ZH.File_CannotPreview = "该文件不支持预览！";
        Resources_ZH.File_Uploading = "该文件正在上传中...";
        Resources_ZH.Error_UploadFailed = "上传失败。错误信息：";
        Resources_ZH.Error_IncorrectFileType = "上传的文件 {0} 类型不正确。";
        Resources_ZH.Error_IncorrectFileSize = "上传的文件 {0} 的大小超出了限制, 最大上传文件的大小为 {1} MB。";
        Resources_ZH.Error_IncorrectFileCount = "上传的文件数量超出了限制, 最大上传数量为 {0}。";
        Resources_ZH.Error_SelectionCannotBeEmpty = "请至少选择一个文件！";
        return Resources_ZH;
    }());
    FilePreviewer.Resources_ZH = Resources_ZH;
    var Resources_JA = /** @class */ (function () {
        function Resources_JA() {
        }
        Resources_JA.Button_Upload = "アップロード";
        Resources_JA.Button_Preview = "プレビュー";
        Resources_JA.Button_Download = "ダウンロード";
        Resources_JA.Button_Delete = "削除";
        Resources_JA.Button_DownloadDirectly = "直接ダウンロード";
        Resources_JA.File_CannotPreview = "このファイルはプレビューできません！";
        Resources_JA.File_Uploading = "ファイルが現在アップロード中です...";
        Resources_JA.Error_UploadFailed = "アップロードに失敗しました。エラーメッセージ：";
        Resources_JA.Error_IncorrectFileType = "アップロードされたファイル {0} のタイプが正しくありません。";
        Resources_JA.Error_IncorrectFileSize = "アップロードされたファイル {0} のサイズが制限を超えています。最大ファイルサイズは {1} MBです。";
        Resources_JA.Error_IncorrectFileCount = "アップロードされたファイルの数が制限を超えています。最大アップロード数は {0} です。";
        Resources_JA.Error_SelectionCannotBeEmpty = "少なくとも1つのファイルを選択してください！";
        return Resources_JA;
    }());
    FilePreviewer.Resources_JA = Resources_JA;
    var Resources_KO = /** @class */ (function () {
        function Resources_KO() {
        }
        Resources_KO.Button_Upload = "업로드";
        Resources_KO.Button_Preview = "미리보기";
        Resources_KO.Button_Download = "다운로드";
        Resources_KO.Button_Delete = "삭제";
        Resources_KO.Button_DownloadDirectly = "즉시 다운로드";
        Resources_KO.File_CannotPreview = "이 파일은 미리보기가 불가능 합니다.";
        Resources_KO.File_Uploading = "현재 파일을 업로드 중입니다...";
        Resources_KO.Error_UploadFailed = "업로드에 실패했습니다. 에러 메시지:";
        Resources_KO.Error_IncorrectFileType = "{0}에 대한 파일 형식이 잘못되었습니다.";
        Resources_KO.Error_IncorrectFileSize = "업로드된 파일 {0}의 크기가 한도를 초과합니다. 최대 업로드 파일 크기는 {1}MB입니다.";
        Resources_KO.Error_IncorrectFileCount = "업로드된 파일 수가 한도를 초과했습니다. 최대 업로드 횟수는 {0}입니다.";
        Resources_KO.Error_SelectionCannotBeEmpty = "파일을 하나 이상 선택하세요!";
        return Resources_KO;
    }());
    FilePreviewer.Resources_KO = Resources_KO;
    switch (Forguncy.RS.Culture) {
        case "EN" /* Forguncy.ForguncySupportCultures.English */:
            window.FilePreviewer.Resources = Resources;
            break;
        case "CN" /* Forguncy.ForguncySupportCultures.Chinese */:
            window.FilePreviewer.Resources = Resources_ZH;
            break;
        case "JA" /* Forguncy.ForguncySupportCultures.Japanese */:
            window.FilePreviewer.Resources = Resources_JA;
            break;
        case "KR" /* Forguncy.ForguncySupportCultures.Korean */:
            window.FilePreviewer.Resources = Resources_KO;
            break;
    }
})(FilePreviewer || (FilePreviewer = {}));
//# sourceMappingURL=Resources.js.map
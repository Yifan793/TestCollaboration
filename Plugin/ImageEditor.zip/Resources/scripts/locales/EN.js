﻿if (!window.ImageEditorResource) {
    window.ImageEditorResource = {};
}

if (!window.ImageEditorResource.Language) {
    window.ImageEditorResource.Language = {};
}

window.ImageEditorResource.Language.EN = {
    Download:"Download",
    Save: "Save",
    Upload: "Upload",
    Error_IncorrectFileType: "The uploaded file {0} is of incorrect type.",
    Error_DonotSave: "Not saving the image.",
    Rotate_Range: "Range",
    Draw_Range: "Range",
};

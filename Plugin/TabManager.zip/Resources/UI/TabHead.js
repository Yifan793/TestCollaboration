var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var TabHeadUI = /** @class */ (function (_super) {
        __extends(TabHeadUI, _super);
        function TabHeadUI() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(TabHeadUI.prototype, "activeTab", {
            set: function (value) {
                this.navWrap.find(".".concat("FTM-nav-wrap-list-item" /* TabHeadClassNames.NavListItem */)).removeClass("selected" /* TabHeadClassNames.Active */);
                if (value) {
                    var activeTab = this.navWrap.find(".".concat("FTM-nav-wrap-list-item" /* TabHeadClassNames.NavListItem */, "[data-uid=\"").concat(value.uid, "\"]"));
                    activeTab.addClass("selected" /* TabHeadClassNames.Active */);
                    this.revealItem(activeTab);
                }
            },
            enumerable: false,
            configurable: true
        });
        // override
        TabHeadUI.prototype.createContainer = function () {
            this.container = $("<div class=\"".concat("FTM-nav" /* TabHeadClassNames.Nav */, "\"></div>"));
        };
        TabHeadUI.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.target.on("TabsChange" /* TabManagerEvents.TabsChanged */, function () {
                _this.createTabs();
            });
            this.target.on("WindowResized" /* TabManagerEvents.WindowResized */, function () {
                _this.updateNav();
            });
            this.target.on("TabsClosedAllOrOther" /* TabManagerEvents.TabsClosedAllOrOther */, function (remainList) {
                _this.closeAllOrOtherTabs(remainList);
            });
        };
        Object.defineProperty(TabHeadUI.prototype, "hasEnoughWidth", {
            get: function () {
                var containerWidth = this.container[0].clientWidth;
                var tabItemsTotalWidth = 0;
                this.navWrap
                    .find(".".concat("FTM-nav-wrap-list-item" /* TabHeadClassNames.NavListItem */))
                    .each(function (index, el) {
                    tabItemsTotalWidth += $(el).width();
                });
                return tabItemsTotalWidth <= containerWidth;
            },
            enumerable: false,
            configurable: true
        });
        // override
        TabHeadUI.prototype.createChildren = function () {
            var _this = this;
            this.navPrev = $("<div class='".concat("FTM-nav-prev" /* TabHeadClassNames.NavPrev */, "'></div>"));
            this.navNext = $("<div class='".concat("FTM-nav-next" /* TabHeadClassNames.NavNext */, "'></div>"));
            this.navMenu = this.target.createUI(TabManager.TabMenuUI).container;
            this.navPrev.on('click', function () {
                _this.movePrev();
            });
            this.navNext.on('click', function () {
                _this.moveNext();
            });
            this.navWrap = $("\n<nav class=\"".concat("FTM-nav-wrap" /* TabHeadClassNames.NavWrap */, "\">\n    <div class=\"").concat("FTM-nav-wrap-placeholder" /* TabHeadClassNames.NavPlaceholder */, "\"><ul class=\"").concat("FTM-nav-wrap-list" /* TabHeadClassNames.NavList */, "\"></ul></div>\n</nav>"));
            this.createTabs();
            this.container.append(this.navPrev, this.navNext, this.navWrap, this.navMenu); // 如果append的是null，则实际上什么也没append到DOM
        };
        Object.defineProperty(TabHeadUI.prototype, "styleTemplateClassName", {
            get: function () {
                if (!this.target.tabStyle) {
                    return "";
                }
                return "TabManagerTabCellType-".concat(this.target.tabStyle.Key, "-TabItem");
            },
            enumerable: false,
            configurable: true
        });
        TabHeadUI.prototype.revealItem = function (item) {
            if (item.length === 0) {
                return;
            }
            var navWrapOffsetLeft = this.navWrap.offset().left;
            var navWrapWidth = this.navWrap.width(); // tab导航的固定宽度
            var itemOffsetLeft = item.offset().left;
            var itemWidth = item.width();
            var placeholder = this.navWrap.find(".".concat("FTM-nav-wrap-placeholder" /* TabHeadClassNames.NavPlaceholder */));
            var currentMarginLeft = parseFloat(placeholder.css('margin-left')); // 未移动之前的 当前margin-left
            var usedMarginLeft = currentMarginLeft;
            if (itemOffsetLeft < navWrapOffsetLeft) {
                // item在左侧 被遮挡
                usedMarginLeft += navWrapOffsetLeft - itemOffsetLeft;
            }
            else if (navWrapOffsetLeft + navWrapWidth <= itemOffsetLeft + itemWidth) {
                // item在右侧 被遮挡
                usedMarginLeft -= itemOffsetLeft + itemWidth - navWrapOffsetLeft - navWrapWidth;
            }
            placeholder.animate({
                "margin-left": "".concat(usedMarginLeft, "px")
            }, TabHeadUI.aminateSpeed);
        };
        TabHeadUI.prototype.moveNext = function () {
            var placeholder = this.navWrap.find(".".concat("FTM-nav-wrap-placeholder" /* TabHeadClassNames.NavPlaceholder */));
            var navWrapWidth = this.navWrap.width(); // tab导航的固定宽度
            var navList = this.navWrap.find(".".concat("FTM-nav-wrap-list" /* TabHeadClassNames.NavList */)); // list的实际总宽度
            var navListWidth = navList.children().map(function (v, d) { return $(d).width(); }).toArray().reduce(function (p, n) { return p + n; });
            if (navListWidth <= navWrapWidth) {
                return;
            }
            var currentMarginLeft = parseFloat(placeholder.css('margin-left')); // 未移动之前的 当前margin-left
            var marginLeftLimit = navListWidth - navWrapWidth; // 最多允许的 margin-left
            var targetMarginLeft = currentMarginLeft - TabHeadUI.navStep; // 根据step算出的将要移动至的 margin-left
            var usedMarginLeft = Math.max(-marginLeftLimit, targetMarginLeft);
            placeholder.animate({
                "margin-left": "".concat(usedMarginLeft, "px")
            }, TabHeadUI.aminateSpeed);
        };
        TabHeadUI.prototype.movePrev = function () {
            var placeholder = this.navWrap.find(".".concat("FTM-nav-wrap-placeholder" /* TabHeadClassNames.NavPlaceholder */));
            var currentMarginLeft = parseFloat(placeholder.css('margin-left')); // 未移动之前的 当前margin-left
            var targetMarginLeft = currentMarginLeft + TabHeadUI.navStep; // 根据step算出的将要移动至的 margin-left
            var usedMarginLeft = Math.min(0, targetMarginLeft); // margin-left 不能为正值 即不会右移动
            placeholder.animate({
                "margin-left": "".concat(usedMarginLeft, "px")
            }, TabHeadUI.aminateSpeed);
        };
        TabHeadUI.prototype.createTabs = function () {
            var _this = this;
            var newTabs = this.target.tabList.map(function (v) {
                var link = $("<a class=\"".concat("FTM-nav-wrap-list-item-link" /* TabHeadClassNames.NavListItemLink */, " ").concat("FTM-f-ellipsis" /* FragmentClassNames.Ellipsis */, "\"></a>"));
                link.text(v.displayedTitle);
                var tab = $("<li data-uid=\"".concat(v.uid, "\" class=\"").concat("FTM-nav-wrap-list-item" /* TabHeadClassNames.NavListItem */, " ").concat(_this.styleTemplateClassName, "\"></li>"))
                    .on("click", function () {
                    _this.target.active(v);
                });
                tab.attr("title", v.displayedTitle).append(link);
                if (v === _this.target.activeTab) {
                    tab.addClass("selected" /* TabHeadClassNames.Active */);
                }
                if (v.canBeClosed) {
                    var close_1 = $("<i class=\"".concat("FTM-nav-wrap-list-item-close" /* TabHeadClassNames.NavListItemClose */, "\"></i>")).on("click", function () {
                        _this.target.closeTab(v);
                    });
                    tab.find(".".concat("FTM-nav-wrap-list-item-link" /* TabHeadClassNames.NavListItemLink */)).append(close_1);
                }
                return tab;
            });
            var navList = this.navWrap.find(".".concat("FTM-nav-wrap-list" /* TabHeadClassNames.NavList */));
            navList.empty();
            navList.append.apply(navList, newTabs);
            this.updateNav();
        };
        TabHeadUI.prototype.closeAllOrOtherTabs = function (remainList) {
            this.navWrap.empty();
            this.navWrap.append($(" <div class=\"".concat("FTM-nav-wrap-placeholder" /* TabHeadClassNames.NavPlaceholder */, "\"><ul class=\"").concat("FTM-nav-wrap-list" /* TabHeadClassNames.NavList */, "\"></ul></div>")));
            if (!remainList.length) {
                return;
            }
            this.createTabs();
        };
        TabHeadUI.prototype.updateNav = function () {
            var isHeaderHasEnoughWidth = this.hasEnoughWidth;
            this.target.isHeaderHasEnoughWidth = isHeaderHasEnoughWidth;
            if (!isHeaderHasEnoughWidth || this.target.cellType.IsExtensionButtonAlwaysShow) {
                this.navMenu.show();
            }
            else {
                this.navMenu.hide();
            }
            if (this.isNavReady === false) {
                return;
            }
            if (this.hasEnoughWidth) {
                this.navPrev.hide();
                this.navNext.hide();
                this.movePrev();
            }
            else {
                this.navPrev.show();
                this.navNext.show();
            }
        };
        Object.defineProperty(TabHeadUI.prototype, "isNavReady", {
            get: function () {
                return !!(this.navPrev || this.navNext);
            },
            enumerable: false,
            configurable: true
        });
        TabHeadUI.navStep = 500;
        TabHeadUI.aminateSpeed = 150;
        return TabHeadUI;
    }(TabManager.ControlUIBase));
    TabManager.TabHeadUI = TabHeadUI;
})(TabManager || (TabManager = {}));
//# sourceMappingURL=TabHead.js.map